import SwiftUI

struct Song {
    let title: String
    let artist: String
}

let playlist: [Song] = [
    Song(title: "Neon Static", artist: "Paper Tigers"),
    Song(title: "Half Past Ten", artist: "Paper Tigers"),
    Song(title: "Cassette Burn", artist: "Paper Tigers"),
    Song(title: "Blue Hour", artist: "Paper Tigers"),
    Song(title: "Grid Lock", artist: "The Ferns"),
    Song(title: "Cold Open", artist: "The Ferns"),
    Song(title: "Static Bloom", artist: "Nova Kids"),
    Song(title: "Last Bus Home", artist: "Nova Kids"),
]

func shufflePlaylist(_ songs: [Song]) -> [Song]? {
    
    while true {
        
        var remainingSongs = songs
        var result: [Song] = []
        
        while result.count < songs.count {
            
            var choices: [Int] = []
            
            for i in 0..<remainingSongs.count {
                
                if result.isEmpty ||
                    remainingSongs[i].artist != result.last!.artist {
                    
                    choices.append(i)
                }
            }
            
            if choices.isEmpty {
                break
            }
            
            let randomIndex = choices.randomElement()!
            let chosenSong = remainingSongs.remove(at: randomIndex)
            
            result.append(chosenSong)
        }
        
        if result.count == songs.count {
            return result
        }
    }
}

struct ContentView: View {
    
    @State var shuffledPlaylist: [Song] = []
    
    var body: some View {
        
        VStack {
            
            Text("Playlist Shuffler")
                .font(.title)
            
            Button("Shuffle Playlist") {
                
                if let newPlaylist = shufflePlaylist(playlist) {
                    shuffledPlaylist = newPlaylist
                    
                    print("Shuffled Playlist:")
                    
                    for i in 0..<newPlaylist.count {
                        print("\(i + 1). \(newPlaylist[i].title) - \(newPlaylist[i].artist)")
                    }
                }
            }
            
            List(shuffledPlaylist.indices, id: \.self) { i in
                
                VStack(alignment: .leading) {
                    Text("\(i + 1). \(shuffledPlaylist[i].title)")
                    
                    Text(shuffledPlaylist[i].artist)
                        .font(.caption)
                }
            }
        }
        .padding()
    }
}
